/**
 * 
 */
/**
 * 
 */
module lab_1b {
}