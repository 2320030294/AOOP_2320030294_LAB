/**
 * 
 */
/**
 * 
 */
module lab_1a {
}